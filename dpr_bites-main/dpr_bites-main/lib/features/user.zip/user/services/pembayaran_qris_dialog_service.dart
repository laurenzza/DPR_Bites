import 'dart:io';
import 'package:dpr_bites/common/utils/base_url.dart';
import 'package:dpr_bites/features/user/models/pembayaran_qris_dialog_model.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class PembayaranQrisDialogService {
  /// Build a full URL to the QRIS image, supporting relative paths from backend.
  static String buildQrisUrl(String? raw) {
    if (raw == null || raw.isEmpty) return '';
    if (raw.startsWith('http')) return raw;
    final cleaned = raw.startsWith('/') ? raw.substring(1) : raw;
    // Prefer configured base URL if available; fall back to emulator base.
    final base = getBaseUrl();
    // Many endpoints are hosted under dpr_bites_api; ensure we don't double-append.
    // If base already ends with /dpr_bites_api, append cleaned directly; else add.
    final baseNormalized = base.endsWith('/')
        ? base.substring(0, base.length - 1)
        : base;
    final apiBase = baseNormalized.contains('dpr_bites_api')
        ? baseNormalized
        : baseNormalized + '/dpr_bites_api';
    return apiBase + '/' + cleaned;
  }

  /// Download a QRIS image to app documents directory, returning local path and filename.
  static Future<QrisDownloadResult> downloadQrisImage(String url) async {
    try {
      if (url.isEmpty) return QrisDownloadResult.failure('URL kosong');
      final resp = await http.get(Uri.parse(url));
      if (resp.statusCode != 200) {
        return QrisDownloadResult.failure(
          'Gagal unduh (HTTP ' + resp.statusCode.toString() + ')',
          statusCode: resp.statusCode,
        );
      }
      final bytes = resp.bodyBytes;
      final fileName =
          'qris_' + DateTime.now().millisecondsSinceEpoch.toString() + '.png';
      final docsDir = await getApplicationDocumentsDirectory();
      final localFile = File(p.join(docsDir.path, fileName));
      await localFile.writeAsBytes(bytes);
      return QrisDownloadResult.success(
        localPath: localFile.path,
        fileName: fileName,
      );
    } catch (e) {
      debugPrint('downloadQrisImage error: ' + e.toString());
      return QrisDownloadResult.failure('Gagal unduh: ' + e.toString());
    }
  }
}
